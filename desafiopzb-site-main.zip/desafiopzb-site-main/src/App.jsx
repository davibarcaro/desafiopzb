import React from 'react';
import Rota from './routes';

function App() {
  

  return <Rota/>;
  
}

export default App
