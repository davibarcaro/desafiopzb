import React,{useState,useEffect,useLayoutEffect} from 'react';
import {Comments,CommentsNews} from '../../comments';
import './style.css';
import logoVideo from '../../assets/logo-video.png';
import Song from '../../assets/song.png';
export default function Video(){
     const [dados,setDados] = useState(Comments);
     const [visitas,setVisitas] = useState("3.219");
     const [peoples,setPeople] = useState("5.219");
     const [getButton, setButton] = useState(false);
    
    
     const visiters = ["3.230","3.339","3.400","3.441"];

     function getRandomInt(min, max) {
      min = Math.ceil(min);
      max = Math.floor(max);
      return Math.floor(Math.random() * (max - min)) + min;
    }

    function openInNewTab(url) {
     window.open(url, '_blank').focus();
    }

useLayoutEffect(() => {
      setVisitas(visiters[getRandomInt(0,3)]);
}, [])

     useEffect(()=>{
          function getRandomIntInclusive(num) {
               return Math.floor(Math.random() * num);
             }
          setTimeout(()=> setDados([CommentsNews[getRandomIntInclusive(1)],...Comments]),7000);
      const pessoas = ["5.230","5.324","5.123","5.221","5.330","5.354","5.423","5.621"];
          setInterval(()=>{
            setPeople(pessoas[getRandomInt(0,7)]);
          },15000);
         setTimeout(()=>{
          setButton(true);

         },1753800);

         
     },[peoples]);
      return (
          <>
          <div className='top-header'>Assista agora o vídeo antes que saía do AR!!!</div>
             <div className='content-home-video'>
                  <header>
                 <div className='img-header'>A mais recém descoberta científica revela a vitamina oriental de <span className='text-2'>6 ingredientes</span> <br></br>simples que ativa o técido anti-gordura <span className='text-2'>e faz derreter mais que academia!</span></div>
                  </header>
                  <div className='video'>
                  <embed width={`100%`} height={`100%`} className='video' src="https://www.youtube-nocookie.com/embed/JzKDw2wyBP4?controls=0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></embed>
                       </div>
                       {getButton && 
                       <div className='button-now'>
                         <button onClick={() => openInNewTab('https://pay.kiwify.com.br/dgfbqVp')} className='button-now-name'>CLIQUE AQUI PARA FAZER PARTE DO DESAFIO</button>
                       </div>}
                  <div className='people-on-the-video'>{peoples} Pessoas simultaneamente assistindo este video.</div>
                  <div className='song'><img src={Song} width={30} height={30}/> Verifique se o áudio está ligado!</div>
{getButton && (
                  <div className="comentarios">
                    { dados.map((item,id) => {
                   return (
                    <>
                    <div className="content">
                    <div className="content-header-comments">
                    <img className="img-comments" key={id} src={item.foto} width={50} height={50}/>  
                    </div>
                    <div className="content-flex">
                    <div className="comment-name">{ item.name }</div>
                    <div className="comment-content">{ item.comment }</div>
                <div className="comment-type">{item.hora=="Agora" ? `Comentado ${item.hora}` : `Comentado há ${item.hora}` }</div>
                    
                    </div>
                   
                    
                    </div>

                    
                    </>
                   ); 
                    
                        }) }
                    </div>
                     )}
             </div>
             </>
      );

}
