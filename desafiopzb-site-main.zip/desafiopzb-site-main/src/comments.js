const Comments = [

 
        {
        foto:"https://img2.migalhas.com.br/_MEDPROC_/author.jpg._PROC_AC334551AT1AP11.jpg",
        name: "Isabely Nunes:",
        foto_comment:false,
        hora:"12 min",
        comment: "Mudar de hábito sempre é bom, é isso mudou tudo em minha vida, passando a me observar mais ainda!",
},
        {
        foto:"https://www.ifsudestemg.edu.br/noticias/reitoria/mais-do-que-existir-ser-mulher-e-resistir/KamilaMagno.png/@@images/f557f0e1-8007-480b-b883-20c16ce35259.png",
        name: "Juliana Santos:",
        foto_comment:false,
        hora:"15 min",
        comment: "Estou contente pelos os resultados que consegui e aprendi nesse tempo, melhorei minha autoestima e hoje consigo me relacionar bem com as pessoas e estou muito feliz!",
            },
                {
                foto:"http://mulherlider.com.br/blog/wp-content/uploads/2016/05/foto-perfil-quadrara.png",
                name: "Roberta Araujo:",
                foto_comment:false,
                hora:"1 min",
                comment: "Quando comecei foi magnífico a transformação de vida e bem estar, me sentindo revigorada!",
                    },{
                        foto:"https://www.residencialviladossonhos.com.br/img/uploads/products/onde-encontrar-asilo-de-mulheres-idosas-no-imirim.jpg",
                        name: "Pamela Souza:",
                        foto_comment:false,
                        hora:"1 hora",
                        comment: "Você me economizou um baita tempo e dinheiro com isso, só tenho a te agradecer. está sendo incrível",
                            },
                    


];
const CommentsNews = [
    {
        foto:"https://extra.globo.com/incoming/18698443-f00-6f6/w533h800/12743699_1031571253580749_3613597705787078626_n.jpg",
        name: "Raína Solange:",
        foto_comment:false,
        hora: "Agora",
        comment: "Estou nesse desafio, e amando o processo dessa evolução!!",
},
{
    foto:"http://1.bp.blogspot.com/-gNlUZ82UKXk/TgZnVXS3KnI/AAAAAAAAAT4/DVzDzkVv5BY/s1600/OgAAAHvYiqqEu9fk11K2c9Rqqa-J5Op2DJ1RSxdzz5Cq4PE7y3khaOW56wLvTZBCSvCe0-3Eyk10LKdKSTphlVShYTkAm1T1UDQIk-4Rf6En5-P1IrAUnWba3_wz.jpg",
    name: "Ana Lúcia:",
    foto_comment:false,
    hora: "Agora",
    comment: "Simplesmente fantástico, é muito bom se sentir bem consigo mesma!",
}
];
export {Comments,CommentsNews};

